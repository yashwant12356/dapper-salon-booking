package com.salon.customer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class BookingRepository {
    private val db=FirebaseFirestore.getInstance()
    private val auth=FirebaseAuth.getInstance()

    fun signIn(onReady:()->Unit, onError:(Exception)->Unit) {
        if(auth.currentUser!=null) onReady()
        else auth.signInAnonymously().addOnSuccessListener { onReady() }.addOnFailureListener { onError(it) }
    }

    fun create(booking:Booking, onDone:()->Unit, onError:(Exception)->Unit) {
        val data=hashMapOf(
            "customerName" to booking.customerName, "phone" to booking.phone,
            "service" to booking.service, "price" to booking.price,
            "durationMinutes" to booking.durationMinutes, "date" to booking.date,
            "time" to booking.time, "status" to booking.status,
            "createdAt" to System.currentTimeMillis()
        )
        db.collection("bookings").add(data).addOnSuccessListener { onDone() }.addOnFailureListener { onError(it) }
    }
}
