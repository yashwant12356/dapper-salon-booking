package com.salon.customer
data class Service(val name:String,val price:Int,val minutes:Int)
data class Booking(val customerName:String,val phone:String,val service:String,val price:Int,val durationMinutes:Int,val date:String,val time:String,val status:String="Pending")
