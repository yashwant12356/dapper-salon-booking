package com.salon.customer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { CustomerApp() } }
}

@Composable fun CustomerApp() {
 val services=listOf(Service("Haircut",200,30),Service("Beard Trim",100,20),Service("Hair + Beard",280,45),Service("Facial",500,45))
 var selected by remember { mutableStateOf<Service?>(null) }
 var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
 var date by remember { mutableStateOf("") }; var time by remember { mutableStateOf("") }
 var message by remember { mutableStateOf("") }
 val repo=remember { BookingRepository() }

 MaterialTheme {
  Column(Modifier.fillMaxSize().padding(20.dp)) {
   Text("YOUR SALON",style=MaterialTheme.typography.headlineMedium)
   Text("Pre-book your slot")
   Spacer(Modifier.height(12.dp))
   LazyColumn(Modifier.weight(1f)) {
    items(services) { s -> Card(Modifier.fillMaxWidth().padding(4.dp),onClick={selected=s}) {
      Row(Modifier.padding(16.dp)) { Column(Modifier.weight(1f)){Text(s.name);Text("${s.minutes} min")};Text("₹${s.price}") }
    }}
   }
   OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Name")})
   OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),label={Text("Mobile")})
   OutlinedTextField(date,{date=it},Modifier.fillMaxWidth(),label={Text("Date e.g. 2026-09-28")})
   OutlinedTextField(time,{time=it},Modifier.fillMaxWidth(),label={Text("Time e.g. 10:30")})
   Button(Modifier.fillMaxWidth(),enabled=selected!=null&&name.isNotBlank()&&phone.isNotBlank()&&date.isNotBlank()&&time.isNotBlank(),
    onClick={
      val s=selected!!
      repo.signIn({ repo.create(Booking(name,phone,s.name,s.price,s.minutes,date,time),{message="Booking sent to salon owner."},{message="Booking failed: ${it.message}"}) },
        {message="Connection failed: ${it.message}"})
    }) { Text("BOOK SLOT") }
   if(message.isNotBlank()) Text(message,Modifier.padding(8.dp))
  }
 }
}
