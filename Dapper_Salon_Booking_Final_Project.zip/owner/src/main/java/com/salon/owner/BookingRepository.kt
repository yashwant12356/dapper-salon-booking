package com.salon.owner

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class BookingRepository {
 private val db=FirebaseFirestore.getInstance(); private val auth=FirebaseAuth.getInstance()
 fun signIn(onReady:()->Unit,onError:(Exception)->Unit){
  if(auth.currentUser!=null) onReady() else auth.signInAnonymously().addOnSuccessListener{onReady()}.addOnFailureListener{onError(it)}
 }
 fun listen(onData:(List<Booking>)->Unit,onError:(Exception)->Unit):ListenerRegistration{
  return db.collection("bookings").orderBy("createdAt").addSnapshotListener{snap,e->
   if(e!=null){onError(e);return@addSnapshotListener}
   val list=snap?.documents?.map{d->Booking(d.id,d.getString("customerName")?:"",d.getString("phone")?:"",d.getString("service")?:"",d.getLong("price")?.toInt()?:0,d.getString("date")?:"",d.getString("time")?:"",d.getString("status")?:"Pending")}?:emptyList()
   onData(list)
  }
 }
 fun status(id:String,value:String)=db.collection("bookings").document(id).update("status",value)
}
