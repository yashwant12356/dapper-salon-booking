package com.salon.owner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{OwnerApp()}}
}

@Composable fun OwnerApp(){
 val repo=remember{BookingRepository()}; var bookings by remember{mutableStateOf(listOf<Booking>())}; var message by remember{mutableStateOf("")}
 LaunchedEffect(Unit){repo.signIn({
   repo.listen({bookings=it},{message=it.message?:"Error"})
 },{message=it.message?:"Login failed"})}
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Text("SALON OWNER",style=MaterialTheme.typography.headlineMedium)
  Text("Live bookings",style=MaterialTheme.typography.titleLarge)
  if(message.isNotBlank())Text(message)
  LazyColumn{
   items(bookings){b->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){
    Column(Modifier.padding(16.dp)){
     Text(b.customerName,style=MaterialTheme.typography.titleMedium)
     Text("${b.service} • ₹${b.price}")
     Text("${b.date} • ${b.time} • ${b.phone}")
     Text("Status: ${b.status}")
     Row{
      Button(onClick={repo.status(b.id,"Confirmed")},Modifier.padding(end=6.dp)){Text("CONFIRM")}
      OutlinedButton(onClick={repo.status(b.id,"Cancelled")}){Text("CANCEL")}
     }
    }
   }}
  }
 }
}
