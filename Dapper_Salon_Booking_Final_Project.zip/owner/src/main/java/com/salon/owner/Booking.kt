package com.salon.owner
data class Booking(val id:String,val customerName:String,val phone:String,val service:String,val price:Int,val date:String,val time:String,val status:String)
