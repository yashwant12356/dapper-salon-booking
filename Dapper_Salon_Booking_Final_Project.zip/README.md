# Salon Booking - Real-Time MVP

Two Android apps:
- customer: customer booking app
- owner: owner booking dashboard

Default menu:
- Haircut ₹200 / 30 min
- Beard Trim ₹100 / 20 min
- Hair + Beard ₹280 / 45 min
- Facial ₹500 / 45 min

## Real-time backend
This project is prepared for Firebase Firestore.

Before building:
1. Create a free Firebase project.
2. Register the Android customer app with package `com.salon.customer`.
3. Register the Android owner app with package `com.salon.owner`.
4. Download each `google-services.json` and place it in:
   - customer/google-services.json
   - owner/google-services.json
5. Enable Firestore and Anonymous Authentication.
6. Apply the rules in `firebase/firestore.rules`.

The current UI is intentionally usable without a backend so the project can be opened and tested immediately. The repository includes the data model and repository layer to connect bookings to Firestore.

## Booking model
Each booking contains:
customerName, phone, service, price, durationMinutes, date, time, status, createdAt.

Recommended Firestore path:
`bookings/{bookingId}`

To prevent double booking, production rules/backend should use a transaction or server-side callable function keyed by date+time.
